package com.arbaelbarca.sub_newbie_dicoding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
